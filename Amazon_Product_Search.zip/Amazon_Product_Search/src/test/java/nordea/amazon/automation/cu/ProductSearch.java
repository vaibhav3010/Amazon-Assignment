//Executable class for feature file "ProductSearch.feature"

package nordea.amazon.automation.cu;

import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
public class ProductSearch {
}